(function(angular) {
  'use strict';
angular.module('ngSwipeRightExample', ['ngTouch']);
})(window.angular);